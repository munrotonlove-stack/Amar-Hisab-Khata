# আমার হিসাব খাতা (Amar Hisab Khata) - Native Android Project

## ওভারভিউ (Overview)
একটি সম্পূর্ণ নির্ভরযোগ্য এবং অফলাইন পার্সোনাল ও প্রাতিষ্ঠানিক হিসাব খাতা নেটিভ অ্যান্ড্রয়েড অ্যাপ্লিকেশন।

## টেকনোলজি স্ট্যাক (Technology Stack)
- Kotlin
- Jetpack Compose with Material 3
- Room Database (Offline-first permanent persistence)
- Coroutines & Flow
- MVVM Architecture

## যেভাবে Android Studio-তে রান করবেন:
1. জিপ ফাইলটি আনজিপ করুন।
2. Android Studio (Ladybug / Koala বা লেটেস্ট) ওপেন করুন।
3. 'Open an Existing Project' নির্বাচন করে এই ফোল্ডারটি ওপেন করুন।
4. Gradle Sync সম্পন্ন হওয়া পর্যন্ত অপেক্ষা করুন।
5. Run 'app' বা সরাসরি 'Generate Signed Bundle / APK' দিয়ে রিয়েল অ্যান্ড্রয়েড ডিভাইসে ইন্সটল করুন!
