package com.amar.hisabkhata.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.amar.hisabkhata.data.local.dao.AppDao
import com.amar.hisabkhata.data.local.entity.*

@Database(
    entities = [
        StudentEntity::class,
        MonthlyFeeEntity::class,
        StudentPaymentEntity::class,
        IncomeEntity::class,
        ExpenseEntity::class,
        DebtEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "amar_hisab_khata.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
