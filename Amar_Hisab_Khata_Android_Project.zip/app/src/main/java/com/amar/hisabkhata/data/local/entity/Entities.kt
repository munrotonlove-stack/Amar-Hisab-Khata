package com.amar.hisabkhata.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phoneNumber: String,
    val monthlyFee: Double,
    val joiningDate: String, // YYYY-MM-DD
    val isActive: Boolean = true,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "monthly_fees")
data class MonthlyFeeEntity(
    @PrimaryKey val id: String,
    val studentId: String,
    val monthYear: String, // YYYY-MM
    val amount: Double,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val status: String, // "paid", "partial", "unpaid"
    val lastPaymentDate: String? = null
)

@Entity(tableName = "student_payments")
data class StudentPaymentEntity(
    @PrimaryKey val id: String,
    val studentId: String,
    val feeId: String,
    val amount: Double,
    val paymentDate: String,
    val monthYear: String,
    val receiptNumber: String,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "incomes")
data class IncomeEntity(
    @PrimaryKey val id: String,
    val category: String, // "student_fee", "madrasa_salary", "mosque_salary", "other_income"
    val title: String,
    val amount: Double,
    val date: String,
    val monthYear: String,
    val isReceived: Boolean = true,
    val receivedDate: String? = null,
    val studentId: String? = null,
    val paymentId: String? = null,
    val notes: String? = null
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val title: String,
    val amount: Double,
    val category: String, // "bazar", "house_rent", "medical", "utility", etc.
    val date: String,
    val monthYear: String,
    val notes: String? = null
)

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey val id: String,
    val personName: String,
    val phoneNumber: String? = null,
    val type: String, // "owe_others" (দেনা), "others_owe_me" (পাওনা)
    val totalAmount: Double,
    val settledAmount: Double = 0.0,
    val remainingAmount: Double = 0.0,
    val date: String,
    val description: String,
    val isFullySettled: Boolean = false
)
