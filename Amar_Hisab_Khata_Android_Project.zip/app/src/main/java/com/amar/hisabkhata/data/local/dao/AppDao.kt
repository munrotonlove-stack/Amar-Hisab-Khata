package com.amar.hisabkhata.data.local.dao

import androidx.room.*
import com.amar.hisabkhata.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Students
    @Query("SELECT * FROM students ORDER BY createdAt DESC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity)

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Query("DELETE FROM students WHERE id = :studentId")
    suspend fun deleteStudent(studentId: String)

    // Monthly Fees
    @Query("SELECT * FROM monthly_fees WHERE monthYear = :monthYear")
    fun getFeesForMonth(monthYear: String): Flow<List<MonthlyFeeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFees(fees: List<MonthlyFeeEntity>)

    @Update
    suspend fun updateFee(fee: MonthlyFeeEntity)

    // Payments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: StudentPaymentEntity)

    // Incomes
    @Query("SELECT * FROM incomes WHERE monthYear = :monthYear ORDER BY date DESC")
    fun getIncomesForMonth(monthYear: String): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM incomes ORDER BY date DESC")
    fun getAllIncomes(): Flow<List<IncomeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncome(income: IncomeEntity)

    @Delete
    suspend fun deleteIncome(income: IncomeEntity)

    // Expenses
    @Query("SELECT * FROM expenses WHERE monthYear = :monthYear ORDER BY date DESC")
    fun getExpensesForMonth(monthYear: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // Debts & Receivables
    @Query("SELECT * FROM debts ORDER BY date DESC")
    fun getAllDebts(): Flow<List<DebtEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: DebtEntity)

    @Update
    suspend fun updateDebt(debt: DebtEntity)

    @Delete
    suspend fun deleteDebt(debt: DebtEntity)
}
