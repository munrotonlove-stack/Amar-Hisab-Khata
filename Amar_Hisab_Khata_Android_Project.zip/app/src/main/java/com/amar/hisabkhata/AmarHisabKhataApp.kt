package com.amar.hisabkhata

import android.app.Application
import com.amar.hisabkhata.data.local.AppDatabase
import com.amar.hisabkhata.data.repository.AppRepository

class AmarHisabKhataApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { AppRepository(database.appDao()) }
}
